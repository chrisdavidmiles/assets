<?php
/**
 * Plugin Name: Dinosaur Game Modification - Space key does not start a game
 * Description: This is a helper plugin for was created in response to a support ticket on wordpress.org. This helper plugin is designed to be used along side the <a href="https://wordpress.org/plugins/dinosaur-game/">Dinosaur Game</a> plugin. This plugin allows customizations to be made to JS, CSS, game sprites, and markup.
 * Version: 1.0
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

// Change this number to clear browser caches any time you update sprites, js, css, or anything else here.
define( 'DINOGAME_VER', '1' );

// URL of directory where plugin assets are found.
define( 'DINOGAME_URL', plugin_dir_url( __FILE__ ) );

// URL of JS file used for game logic.
define( 'DINOGAME_JS', plugins_url( 'game-logic.js', __FILE__) );

// URL of CSS file used for game style.
define( 'DINOGAME_CSS', plugins_url( 'game-style.css', __FILE__) );

// 1x Spritemap filename.
define( 'DINOGAME_S1X', 'game-spritemap-1x.png' );

// 2x Spritemap filename.
define( 'DINOGAME_S2X', 'game-spritemap-2x.png' );

/* That's all, stop editing! Happy publishing. */

if ( file_exists ( plugin_dir_path( __FILE__ ) . 'dependency-check.php' ) ) {
   include_once( plugin_dir_path( __FILE__ ) . 'dependency-check.php' );
}

