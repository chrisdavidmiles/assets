<?php
/**
 * Plugin Name: Dinosaur Game - Customizations
 * Description: This is a helper plugin for goldenpianoman.com created in response to a support ticket. This helper plugin is designed to be used along side the <a href="https://wordpress.org/plugins/dinosaur-game/">Dinosaur Game</a> plugin. This plugin allows customizations to be made to JS, CSS, game sprites, and markup.
 * Version: 1.0
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

// Change this number to clear browser caches any time you update sprites, js, css, or anything else here.
define( 'DINOGAME_VER', '1' );

// URL of directory where plugin assets are found.
define( 'DINOGAME_URL', plugin_dir_url( __FILE__ ) );

// URL of JS file used for game logic.
define( 'DINOGAME_JS', plugins_url( 'game-logic.js', __FILE__) );

// URL of CSS file used for game style.
define( 'DINOGAME_CSS', plugins_url( 'game-style.css', __FILE__) );

// Spritemap (img) classes added for compatibility.
define( 'DINOGAME_SMC', 'a3-notlazy disable-lazyload no-lazy no-lazyload skip-lazy' );

// Spritemap (img) attributes added for compatibility.
define( 'DINOGAME_SMA', 'data-lazy-src data-crazy-lazy="exclude" data-no-lazy data-no-lazy="1"' );

// 1x Spritemap filename.
define( 'DINOGAME_S1X', 'game-spritemap-1x.png' );

// 2x Spritemap filename.
define( 'DINOGAME_S2X', 'game-spritemap-2x.png' );

// Allows duplicate check to be turned off as some caching plugins don't work well with duplicate check).
define( 'DINOGAME_DUPLICATE_CHECK', true );

/* That's all, stop editing! Happy publishing. */

if ( file_exists ( plugin_dir_path( __FILE__ ) . 'dependency-check.php' ) ) {
   include_once( plugin_dir_path( __FILE__ ) . 'dependency-check.php' );
}

