<?php

// This code checks if the Dinosaur Game plugin is active.
// If you don't want this check to happen, just delete this file.

if ( ! defined( 'ABSPATH' ) )  die; 

function dinogame_custom_asset_dependency_check() {
   global $pagenow; 
   if ($pagenow == 'plugins.php') {
      $dinogame_plugin_path = WP_PLUGIN_DIR . '/dinosaur-game/dinosaur-game.php';
      $dinogame_plugin_is_installed = file_exists( $dinogame_plugin_path );
      $dinogame_plugin_is_active = is_plugin_active('dinosaur-game/dinosaur-game.php');
      if ( ! $dinogame_plugin_is_active ) {
         if ( ! $dinogame_plugin_is_installed ) {
         echo '<div class="notice notice-warning"><h2 style="margin-bottom:0.75em;">Warning</h2><p>The <strong>Dinosaur Game - Customizations</strong> plugin which is currently installed, doesn\'t work without the <strong>Dinosaur Game</strong> plugin also installed and activated. </p><p>Please install and activate the <a href="' . admin_url() . 'plugin-install.php?s=dinosaur-game&tab=search&type=term" target="_blank"><strong>Dinosaur Game</strong></a> plugin to use the <code>[dinosaur-game]</code> shortcode.</p></div>';
         } else {
         echo '<div class="notice notice-warning"><h2 style="margin-bottom:0.75em;">Warning</h2><p>The <strong>Dinosaur Game - Customizations</strong> plugin doesn\'t work without the <strong>Dinosaur Game</strong> plugin activated. </p><p>Please activate the <a href="' . admin_url() . 'plugin-install.php?s=dinosaur-game&tab=search&type=term" target="_blank"><strong>Dinosaur Game</strong></a> plugin to use the <code>[dinosaur-game]</code> shortcode.</p></div>';
         }
      }
   }
}

add_action( 'admin_init', 'dinogame_custom_asset_dependency_check' );

