<?php

/**
 * Plugin Name:       Remove Admin Email Verification
 * Plugin URI:        https://gist.github.com/chrisdavidmiles/94f58cc60fdb34d06a13f946f8ffd155
 * Description:       Removes the step in /wp-login.php that occasionally asks to confirm if the email on file for a site is still correct.
 * Version:           1.0
 * Requires at least: 5.3
 */
 
add_filter( 'admin_email_check_interval', '__return_false' );
