<?php
/**
 * The index page of Food
 *
 * Displays the home page elements.
 *
 * @package Food
 *
 * @since PT Food 1.0
 */
global $complete;
?>
<?php get_header(); ?>
<?php if ( is_front_page() ) { ?>
<div class="fixed_site layer_wrapper">
  <div class="fixed_wrap fixindex">
    <!-- Home Section 1 -->
	<?php if($complete['hide_boxes_section1'] == ''){?>   
    <section class="home1_section_area <?php if($complete['section1_bg_image']){ ?>home1_section_area_bg<?php } ?>" <?php if(!empty($complete['section1_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec1bgvideo = $complete['section1_bg_video']; echo do_shortcode($sec1bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section1_content">
             	  <?php
				  	$pagesetting1 = get_theme_mod( 'page-setting1');
					if ($pagesetting1 == '0'){
						echo ''.do_shortcode('[centertitle text="Our Services" titlecolor="#232323" boxboder="#ff9c00" seperatorcolor="#e6e6e6"][space height="40"][columns size="2"] &nbsp;[/columns][columns size="2"][service pattern="boxpattern-3" icon="'.get_template_directory_uri().'/images/services-1.png" title="Meat" go="" url="#"]Lorem ipsum d siame consectetur adipiscing eullam est liberolacinia id massa...[/service][service pattern="boxpattern-3" icon="'.get_template_directory_uri().'/images/services-2.png" title="Sweet" go="" url="#"]Lorem ipsum d siame consectetur adipiscing eullam est liberolacinia id massa...[/service][service pattern="boxpattern-3" icon="'.get_template_directory_uri().'/images/services-3.png" title="Quick Food" go="" url="#"]Lorem ipsum d siame consectetur adipiscing eullam est liberolacinia id massa...[/service][service pattern="boxpattern-3" icon="'.get_template_directory_uri().'/images/services-4.png" title="Hot Food" go="" url="#"]Lorem ipsum d siame consectetur adipiscing eullam est liberolacinia id massa...[/service][/columns]');	
					}
					else
					{
					$secone = new WP_Query('page_id='.$pagesetting1.'');
					while ($secone->have_posts()) : $secone->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
    <!-- Home Section 1 -->
    <!-- Home Section 2 -->
    <?php if($complete['hide_boxes_section2'] ==''){?>
    <section class="home2_section_area <?php if($complete['section2_bg_image']){ ?>home2_section_area_bg<?php } ?>" <?php if(!empty($complete['section2_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec2bgvideo = $complete['section2_bg_video']; echo do_shortcode($sec2bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section2_content">
                    <?php
				  	$pagesetting2 = get_theme_mod( 'page-setting2');
					if ($pagesetting2 == '0'){
						echo ''.do_shortcode('[centertitle text="Our Menu" titlecolor="#232323" boxboder="#ff9c00" seperatorcolor="#ececec"][space height="50"]<p style="text-align:center; font-weight:300; font-style:italic;">Pellentesque quis pellentesque lacus. Curabitur fermentum elit est, at ultricies nibh malesuada in. Mauris dapibus sed nibh in venenatis. Mauris malesuada tempor Mauris malesuada tempor Mauris malesuada tempor ex Mauris malesuada tempor ex, quis semper justo varius et. Pellentesque volutpat facilisis ligula in varius facilisis. Fusce augue orci, varius quis tempus et, consequat ac sem. </p>
[clear][space height="130"][columns size="2"]

[ourmenu filter="true" show="4" menuexcerptlength="15" allmenu="All Menu" showimage=""]

[/columns][columns size="2"]<div class="doublebutton">[readmore align="center" icon="shopping-cart" button="FREE DELIVERY" links="#" margintop="0" target="_parent" color="#ffffff" bgcolor="#282828"][readmore align="center" icon="tag" button="ONLINE ORDER" links="#" margintop="0" target="_parent" color="#ff9c00" bgcolor="#ffffff"] [clear]</div>

[readmore align="center" button="VIEW ALL MENU" links="https://www.pinnaclethemes.net/themedemos/food/our-menu/" margintop="70%" target="_parent" color="#ffffff" bgcolor="#ff9c00"][clear] [/columns][clear]');	
					}
					else
					{
					$sectwo = new WP_Query('page_id='.$pagesetting2.'');
					while ($sectwo->have_posts()) : $sectwo->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
    <!-- Home Section 2 --> 
    <!-- Home Section 3 -->
     <?php if($complete['hide_boxes_section3'] ==''){?>
    <section id="demos" class="home3_section_area <?php if($complete['section3_bg_image']){ ?>home3_section_area_bg<?php } ?>" <?php if(!empty($complete['section3_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec3bgvideo = $complete['section3_bg_video']; echo do_shortcode($sec3bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section3_content">
                    <?php
				  	$pagesetting3 = get_theme_mod( 'page-setting3');
					if ($pagesetting3 == '0'){
						echo ''.do_shortcode('[centertitle text="Our Chef" titlecolor="#232323" boxboder="#ff9c00"  seperatorcolor="#ececec"][space height="50"]<p style="text-align:center; font-weight:300; font-style:italic;">Pellentesque quis pellentesque lacus. Curabitur fermentum elit est, at ultricies nibh malesuada in. Mauris dapibus sed nibh in venenatis. Mauris malesuada tempor Mauris malesuada tempor Mauris malesuada tempor ex Mauris malesuada tempor ex, quis semper justo varius et. Pellentesque volutpat facilisis ligula in varius facilisis. Fusce augue orci, varius quis tempus et, consequat ac sem. </p>
						[space height="40"][clear][ourteam col="4" show="4" excerptlength="" readmore="READ MORE"]');
					}
					else
					{
					$secthree = new WP_Query('page_id='.$pagesetting3.'');
					while ($secthree->have_posts()) : $secthree->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>             
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
    <!-- Home Section 3 -->  
    <!-- Home Section 4 -->
     <?php if($complete['hide_boxes_section4'] ==''){?>
    <section class="home4_section_area <?php if($complete['section4_bg_image']){ ?>home4_section_area_bg<?php } ?>" <?php if(!empty($complete['section4_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec4bgvideo = $complete['section4_bg_video']; echo do_shortcode($sec4bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section4_content">
                    <?php
				  	$pagesetting4 = get_theme_mod( 'page-setting4');
					if ($pagesetting4 == '0'){
						echo '<div class="center-title"><h2 style="color:#232323">Book Your Table</h2>
						<div class="boxboder" style="background:#ff9c00"></div>
						<span style="border-bottom-color:#d6d5d5"></span></div><div class="spacecode" style="height:50px;"></div><div class="columns-2"><div role="form" class="wpcf7" id="wpcf7-f4-o1" dir="ltr" lang="en-US"><div class="screen-reader-response"></div><form action="#wpcf7-f4-o1" method="post" class="wpcf7-form" novalidate="novalidate"><div style="display: none;"><input name="_wpcf7" value="4" type="hidden"><input name="_wpcf7_version" value="4.5.1" type="hidden"><input name="_wpcf7_locale" value="en_US" type="hidden"><input name="_wpcf7_unit_tag" value="wpcf7-f4-o1" type="hidden"><input name="_wpnonce" value="d26c7637cb" type="hidden"></div><p><span class="wpcf7-form-control-wrap your-name"><input name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Name" type="text"></span></p><p><span class="wpcf7-form-control-wrap your-tel"><input name="your-tel" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="Mobile Number" type="tel"></span> </p><p><span class="wpcf7-form-control-wrap your-email"><input name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Your Email" type="email"></span></p><p><span class="wpcf7-form-control-wrap your-date"><input name="your-date" value="" size="40" class="wpcf7-form-control wpcf7-date your-datepicker hasDatepicker" placeholder="Date" id="dp1479885257626" type="text"> </span></p><p><span class="wpcf7-form-control-wrap your-time"><input name="your-time" value="" size="40" class="wpcf7-form-control wpcf7-date wpcf7-time hasDatepicker" placeholder="Time" id="dp1479885257627" type="text"> </span></p><p><span class="wpcf7-form-control-wrap your-name"><input name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="No of Person" type="text"></span></p><p><input value="BOOK NOW" class="wpcf7-form-control wpcf7-submit" type="submit"><img class="ajax-loader" src="#" alt="Sending ..." style="visibility: hidden;"></p><div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div><div class="columns-2">&nbsp;</div><div class="clear"></div>';	
					}
					else
					{
					$secfour = new WP_Query('page_id='.$pagesetting4.'');
					while ($secfour->have_posts()) : $secfour->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>              
            </div>
        </div>
    </section>
    <?php } ?>
    <!-- Home Section 4 -->
    <!-- Home Section 5 -->
     <?php if($complete['hide_boxes_section5'] ==''){?>
    <section class="home5_section_area <?php if($complete['section5_bg_image']){ ?>home5_section_area_bg<?php } ?>" <?php if(!empty($complete['section5_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec5bgvideo = $complete['section5_bg_video']; echo do_shortcode($sec5bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section5_content">
                    <?php
				  	$pagesetting5 = get_theme_mod( 'page-setting5');
					if ($pagesetting5 == '0'){
						echo ''.do_shortcode('[centertitle text="Latest News" titlecolor="#232323" boxboder="#ff9c00" seperatorcolor="#ececec"][space height="50"]<p style="text-align:center; font-weight:300; font-style:italic;">Aliquam sodales viverra dictum. Ut magna lectus, efficitur nec rhoncus quis, pretium ut arcu. Pellentesque quis pellentesque lacus. Curabitur  quis semper justo varius et fermentum elit est, at ultricies nibh malesuada in. Mauris dapibus sed nibh in venenatis. Mauris malesuada tempor ex, quis semper justo varius et.</p>
						[space height="70"][posts-style4 show="3" cat="" excerptlength="" readmore=""]');	
					}
					else
					{
					$secfive = new WP_Query('page_id='.$pagesetting5.'');
					while ($secfive->have_posts()) : $secfive->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>            
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
    <!-- Home Section 5 -->
    <!-- Home Section 6 -->
     <?php if($complete['hide_boxes_section6'] ==''){?>
    <section class="home6_section_area <?php if($complete['section6_bg_image']){ ?>home6_section_area_bg<?php } ?>" <?php if(!empty($complete['section6_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec6bgvideo = $complete['section6_bg_video']; echo do_shortcode($sec6bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section6_content">
                    <?php
				  	$pagesetting6 = get_theme_mod( 'page-setting6');
					if ($pagesetting6 == '0'){
						echo ''.do_shortcode('[space height="50"][testimonials-rotator show="-1"]');	
					}
					else
					{
					$secsix = new WP_Query('page_id='.$pagesetting6.'');
					while ($secsix->have_posts()) : $secsix->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>               
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
    <!-- Home Section 6 -->
    <!-- Home Section 7 -->
    <?php if($complete['hide_boxes_section7'] ==''){?>
    <section class="home7_section_area <?php if($complete['section7_bg_image']){ ?>home7_section_area_bg<?php } ?>" <?php if(!empty($complete['section7_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec7bgvideo = $complete['section7_bg_video']; echo do_shortcode($sec7bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section7_content">
                    <?php
				  	$pagesetting7 = get_theme_mod( 'page-setting7');
					if ($pagesetting7 == '0'){
						echo '<div class="columns-2">&nbsp;</div> <div class="columns-2"><div class="spacecode" style="height:30px;"></div><a href="#"><div class="squarebox"><div class="squareicon"><img src="'.get_template_directory_uri().'/images/blocks1.png" /></div><div class="squaretitle">Mobile Friendly</div></div></a><a href="#"><div class="squarebox"><div class="squareicon"><img src="'.get_template_directory_uri().'/images/color-picker.png" /></div><div class="squaretitle">Color Picker</div></div></a><a href="#"><div class="squarebox"><div class="squareicon"><img src="'.get_template_directory_uri().'/images/ample-shortcodes.png" /></div><div class="squaretitle">Ample Shortcodes</div></div></a><a href="#"><div class="squarebox"><div class="squareicon"><img src="'.get_template_directory_uri().'/images/page-builder.png" /></div><div class="squaretitle">Page Builder</div></div></a><a href="#"><div class="squarebox"><div class="squareicon"><img src="'.get_template_directory_uri().'/images/fully-documented.png" /></div><div class="squaretitle">Fully Documented</div></div></a><a href="#"><div class="squarebox"><div class="squareicon"><img src="'.get_template_directory_uri().'/images/translation-ready.png" /></div><div class="squaretitle">Translation Ready</div></div></a><div class="spacecode" style="height:10px;"></div></div>';	
					}
					else
					{
					$secseven = new WP_Query('page_id='.$pagesetting7.'');
					while ($secseven->have_posts()) : $secseven->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>                           
            </div>
        </div>
    </section>
    <?php wp_reset_postdata(); ?>
    <?php } ?>
    <!-- Home Section 7 -->
    <!-- Home Section 8 -->
     <?php if($complete['hide_boxes_section8'] ==''){?>
    <section class="home8_section_area <?php if($complete['section8_bg_image']){ ?>home8_section_area_bg<?php } ?>" <?php if(!empty($complete['section8_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec8bgvideo = $complete['section8_bg_video']; echo do_shortcode($sec8bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section8_content">
                    <?php
				  	$pagesetting8 = get_theme_mod( 'page-setting8');
					if ($pagesetting8 == '0'){
						echo '<div style="background-color:#ff8800;" class="promo5"><h2 style="color:#ffffff;">Create Stunning Websites. Purchase Food Theme. Just $49</h2><div class="ptmore"><a href="#">GET YOUR COPY</a></div> </div>';	
					}
					else
					{
					$seceight = new WP_Query('page_id='.$pagesetting8.'');
					while ($seceight->have_posts()) : $seceight->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>            
            </div>
        </div>
    </section>
    <?php wp_reset_postdata(); ?>
    <?php } ?>
    <!-- Home Section 8 -->
    <!-- Home Section 9 -->
     <?php if($complete['hide_boxes_section9'] ==''){?>
    <section class="home9_section_area <?php if($complete['section9_bg_image']){ ?>home9_section_area_bg<?php } ?>" <?php if(!empty($complete['section9_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec9bgvideo = $complete['section9_bg_video']; echo do_shortcode($sec9bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section9_content">
                    <?php
				  	$pagesetting9 = get_theme_mod( 'page-setting9');
					if ($pagesetting9 == '0' ){
						echo '<div class="center-title"><h2 style="color:#282828">Food Core Features.</h2><span style="border-bottom-color:#e8e7e7"></span></div><div style="height:30px;" class="spacecode"></div>'.do_shortcode('[posts-style3 show="12" cat="1" excerptlength="24"]');	
					}
					else
					{
					$secnine = new WP_Query('page_id='.$pagesetting9.'');
					while ($secnine->have_posts()) : $secnine->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>             
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
    <!-- Home Section 9 -->
    <!-- Home Section 10 -->
     <?php if($complete['hide_boxes_section10'] == '' ){?>
    <section class="home10_section_area <?php if($complete['section10_bg_image']){ ?>home10_section_area_bg<?php } ?>" <?php if(!empty($complete['section10_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec10bgvideo = $complete['section10_bg_video']; echo do_shortcode($sec10bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section10_content">
                    <?php
				  	$pagesetting10 = get_theme_mod( 'page-setting10');
					if ($pagesetting10 == '0'){
						echo '<div class="center-title"><h2 style="color:#ffffff">Create easily anything you want with Food.</h2><span style="border-bottom-color:#ffffff"></span></div><div style="height:30px;" class="spacecode"></div><p><img width="1149" height="620" sizes="(max-width: 1149px) 100vw, 1149px" alt="create-easily" src="'.get_template_directory_uri().'/images/create-easily.png" class="aligncenter size-full"></p>';	
					}
					else
					{
					$secten = new WP_Query('page_id='.$pagesetting10.'');
					while ($secten->have_posts()) : $secten->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>             
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
    <!-- Home Section 10 -->
    <!-- Home Section 11 -->
     <?php if($complete['hide_boxes_section11'] ==''){?>
    <section class="home11_section_area <?php if($complete['section11_bg_image']){ ?>home11_section_area_bg<?php } ?>" <?php if(!empty($complete['section11_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec11bgvideo = $complete['section11_bg_video']; echo do_shortcode($sec11bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section11_content">
                    <?php
				  	$pagesetting11 = get_theme_mod( 'page-setting11');
					if ($pagesetting11 == '0' ){
						echo '<div class="center-title"><h2 style="color:#282828">Food is also compatible with.</h2><span style="border-bottom-color:#e8e7e7"></span></div><div style="height:40px;" class="spacecode"></div><div class="perfectbox"><a href="#"><div class="perfectborder"> <div class="perf-thumb"><img src="'.get_template_directory_uri().'/images/woo-thumb.png"/></div> <div class="perf-title"><h3>WOOCOMMERCE</h3></div> <div class="perf-description">for building advanced shops</div></div></a></div><div class="perfectbox"><a href="#"><div class="perfectborder"> <div class="perf-thumb"><img src="'.get_template_directory_uri().'/images/thumb-translate.png"/></div> <div class="perf-title"><h3>Q TRANSLATE X</h3></div> <div class="perf-description">for language translation</div></div></a></div><div class="perfectbox"><a href="#"><div class="perfectborder"> <div class="perf-thumb"><img src="'.get_template_directory_uri().'/images/con7-thumb.png"/></div> <div class="perf-title"><h3>CONTACT FORM 7</h3></div> <div class="perf-description">for building great forms</div></div></a></div><div class="perfectbox"><a href="#"><div class="perfectborder"> <div class="perf-thumb"><img src="'.get_template_directory_uri().'/images/crelly-slider.png"/></div> <div class="perf-title"><h3>CRELLY SLIDER</h3></div> <div class="perf-description">for layered slider</div></div></a></div><div class="perfectbox"><a href="#"><div class="perfectborder"> <div class="perf-thumb"><img src="'.get_template_directory_uri().'/images/event-thumb.png"/></div> <div class="perf-title"><h3>THE EVENT CALENDAR</h3></div> <div class="perf-description">for better organization</div></div></a></div><div class="perfectbox"><a href="#"><div class="perfectborder"> <div class="perf-thumb"><img src="'.get_template_directory_uri().'/images/bb-thumb.png"/></div> <div class="perf-title"><h3>BBPRESS</h3></div> <div class="perf-description">for social sharing</div></div></a></div><div class="perfectbox"><a href="#"><div class="perfectborder"> <div class="perf-thumb"><img src="'.get_template_directory_uri().'/images/cyclone-slider.png"/></div> <div class="perf-title"><h3>CYCLONE SLIDER</h3></div> <div class="perf-description">for simple video slider</div></div></a></div><div class="perfectbox"><a href="#"><div class="perfectborder"> <div class="perf-thumb"><img src="'.get_template_directory_uri().'/images/nextgen-gallery.png"/></div> <div class="perf-title"><h3>NEXTGEN GALLERY</h3></div> <div class="perf-description">for photo gallery</div></div></a></div><div class="perfectbox"><a href="#"><div class="perfectborder"> <div class="perf-thumb"><img src="'.get_template_directory_uri().'/images/yoast-seo.png"/></div> <div class="perf-title"><h3>YOAST SEO</h3></div> <div class="perf-description">for SEO meta tags</div></div></a></div>';	
					}
					else
					{
					$seceleven = new WP_Query('page_id='.$pagesetting11.'');
					while ($seceleven->have_posts()) : $seceleven->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php
					}
					?>             
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
    <!-- Home Section 11 -->  
	<!-- Home Section 12 -->
	<?php if($complete['hide_boxes_section12'] ==''){?>
    <section class="home12_section_area <?php if($complete['section12_bg_image']){ ?>home12_section_area_bg<?php } ?>" <?php if(!empty($complete['section12_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec12bgvideo = $complete['section12_bg_video']; echo do_shortcode($sec12bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section12_content">
                <?php
                $pagesetting12 = get_theme_mod( 'page-setting12');
                if ($pagesetting12 == '0' ){
                    echo '<div class="center-title"><h2 style="color:#ffffff">Build amazing sites using Food Shortcodes.</h2><span style="border-bottom-color:#ffffff"></span></div><img class="aligncenter" src="'.get_template_directory_uri().'/images/perfect-shortcodes.png" />';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting12.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
	<!-- Home Section 12 -->
	<!-- Home Section 13 -->
	<?php if($complete['hide_boxes_section13'] ==''){?>
    <section class="home13_section_area <?php if($complete['section13_bg_image']){ ?>home13_section_area_bg<?php } ?>" <?php if(!empty($complete['section13_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec13bgvideo = $complete['section13_bg_video']; echo do_shortcode($sec13bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section13_content">
                <?php
                $pagesetting13 = get_theme_mod( 'page-setting13');
                if ($pagesetting13 == '0' ){
                    echo '<div class="center-title"><h2 style="color:#282828">4 Food Blog Templates.</h2><span style="border-bottom-color:#e8e7e7"></span></div><div style="height:20px;" class="spacecode"></div><p style="text-align: center;">You can use different blog Templates for your website</p><div style="height:40px;" class="spacecode"></div><div class="columns-4"><div class="blockbox"><a href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/blog-right-sidebar.png" /></div><div class="infoblocktitle"><h4>BLOG RIGHT SIDEBAR</h4></div></a></div></div><div class="columns-4"><div class="blockbox"><a href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/blog-left-sidebar.png" /></div><div class="infoblocktitle"><h4>BLOG LEFT SIDEBAR</h4></div></a></div></div><div class="columns-4"><div class="blockbox"><a href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/blog-full-width.png" /></div><div class="infoblocktitle"><h4>BlOG FULL WIDTH</h4></div></a></div></div><div class="columns-4"><div class="blockbox"><a href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/blog-no-sidebar.png" /></div><div class="infoblocktitle"><h4>BLOG NO SIDEBAR</h4></div></a></div></div>';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting13.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
	<!-- Home Section 13 -->
	<!-- Home Section 14 -->
	<?php if($complete['hide_boxes_section14'] ==''){?>
    <section class="home14_section_area <?php if($complete['section14_bg_image']){ ?>home14_section_area_bg<?php } ?>" <?php if(!empty($complete['section14_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec14bgvideo = $complete['section14_bg_video']; echo do_shortcode($sec14bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section14_content">
                <?php
                $pagesetting14 = get_theme_mod( 'page-setting14');
                if ($pagesetting14 == '0' ){
                    echo '<div class="columns-2"><div class="center-title"><h2 style="color:#ffffff">4 Food Header Styles.</h2><span style="border-bottom-color:#ffffff"></span></div><div style="height:50px;" class="spacecode"></div><div class="columns-2"><div class="blockbox"><a target="_self" href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/header-style-1.png" /></div><div class="infoblocktitle"><h4 style="color:#ffffff;">HEADER STYLE 1</h4></div></a></div></div><div class="columns-2"><div class="blockbox"><a target="_self" href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/header-style-2.png" /></div><div class="infoblocktitle"><h4 style="color:#ffffff;">HEADER STYLE 2</h4></div></a></div></div><div class="clear"></div><div class="columns-2"><div class="blockbox"><a target="_self" href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/header-style-3.png" /></div><div class="infoblocktitle"><h4 style="color:#ffffff;">HEADER STYLE 3</h4></div></a></div></div><div class="columns-2"><div class="blockbox"><a target="_self" href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/header-style-4.png" /></div><div class="infoblocktitle"><h4 style="color:#ffffff;">HEADER STYLE 4</h4></div></a></div></div></div><div class="columns-2"><div class="center-title"><h2 style="color:#ffffff">4 Food  Styles.</h2><span style="border-bottom-color:#ffffff"></span></div><div style="height:50px;" class="spacecode"></div><div class="columns-2"><div class="blockbox"><a target="_self" href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/footer-style-1.png" /></div><div class="infoblocktitle"><h4 style="color:#ffffff;">FOOTER STYLE 1</h4></div></a></div></div><div class="columns-2"><div class="blockbox"><a target="_self" href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/footer-style-2.png" /></div><div class="infoblocktitle"><h4 style="color:#ffffff;">FOOTER STYLE 2</h4></div></a></div></div><div class="clear"></div><div class="columns-2"><div class="blockbox"><a target="_self" href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/footer-style-3.png" /></div><div class="infoblocktitle"><h4 style="color:#ffffff;">FOOTER STYLE 3</h4></div></a></div></div><div class="columns-2"><div class="blockbox"><a target="_self" href="#"><div class="infoblockthumb"><img src="'.get_template_directory_uri().'/images/footer-style-4.png" /></div><div class="infoblocktitle"><h4 style="color:#ffffff;">FOOTER STYLE 4</h4></div></a></div></div></div>';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting14.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
	<!-- Home Section 14 -->
	<!-- Home Section 15 -->
	<?php if($complete['hide_boxes_section15'] ==''){?>
    <section class="home15_section_area <?php if($complete['section15_bg_image']){ ?>home15_section_area_bg<?php } ?>" <?php if(!empty($complete['section15_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec15bgvideo = $complete['section15_bg_video']; echo do_shortcode($sec15bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section15_content">
                <?php
                $pagesetting15 = get_theme_mod( 'page-setting15');
                if ($pagesetting15 == '0' ){
                   echo ''.do_shortcode('[space height="50"][testimonials-rotator show="-1"]');
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting15.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
	<!-- Home Section 15 -->
	<!-- Home Section 16 -->
	<?php if($complete['hide_boxes_section16'] ==''){?>
    <section class="home16_section_area <?php if($complete['section16_bg_image']){ ?>home16_section_area_bg<?php } ?>" <?php if(!empty($complete['section16_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec16bgvideo = $complete['section16_bg_video']; echo do_shortcode($sec16bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section16_content">
                <?php
                $pagesetting16 = get_theme_mod( 'page-setting16');
                if ($pagesetting16 == '0' ){
                    echo '<div class="center-title"><h2 style="color:#282828;">Food Partners.</h2><span style="border-bottom-color:#e8e7e7;"></span></div><div style="height:50px;" class="spacecode"></div><div class="clientarea"><div class="clientbox"> <a target="_blank" href="#"><img src="'.get_template_directory_uri().'/images/wp.png"></a> </div><div class="clientbox"> <a target="_blank" href="#"><img src="'.get_template_directory_uri().'/images/jquery.jpg"></a> </div><div class="clientbox"> <a target="_blank" href="#"><img src="'.get_template_directory_uri().'/images/woocommerce.jpg"></a> </div><div class="clientbox"> <a target="_blank" href="#"><img src="'.get_template_directory_uri().'/images/bbpress-client.jpg"></a> </div><div class="clientbox"> <a target="_blank" href="#"><img src="'.get_template_directory_uri().'/images/mysql.jpg"></a> </div><div class="clientbox"> <a target="_blank" href="#"><img src="'.get_template_directory_uri().'/images/jquery.jpg"></a> </div></div>';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting16.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
	<!-- Home Section 16 -->
	<!-- Home Section 17 -->
	<?php if($complete['hide_boxes_section17'] ==''){?>
    <section class="home17_section_area <?php if($complete['section17_bg_image']){ ?>home17_section_area_bg<?php } ?>" <?php if(!empty($complete['section17_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec17bgvideo = $complete['section17_bg_video']; echo do_shortcode($sec17bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    <div class="center">
        <div class="home_section17_content">
                <?php
                $pagesetting17 = get_theme_mod( 'page-setting17');
                if ($pagesetting17 == '0' ){
                    echo 'Section 17 Content';	
                }
                else
                {
                $seceleven = new WP_Query('page_id='.$pagesetting17.'');
                while ($seceleven->have_posts()) : $seceleven->the_post();
                ?>
                <?php the_content(); ?>
                <?php endwhile; wp_reset_postdata(); ?>
                <?php
                }
                ?>             
        </div>
    </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
	<!-- Home Section 17 -->                
  </div>
</div>
<?php }else{ ?>
<div class="fixed_site">
  <div class="fixed_wrap fixindex">
    <?php get_template_part('templates/post','layout4'); ?>
  </div>
</div>
<?php } //is_front_page ENDS ?>
<?php get_footer(); ?>