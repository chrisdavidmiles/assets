/*-----------------------------------------------------------------------------------*/
/* Food Responsive WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   Food
Theme URI       :   https://www.pinnaclethemes.net/product/restaurant-wordpress-theme/
Version         :   pro1.0
Tested up to    :   WP 4.8
Author          :   Pinnacle Themes
Author URI      :   https://www.pinnaclethemes.net/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@pinnaclethemes.net

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/
Click on Documentation and Support.

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
- jquery.nivo.slider.js is licensed under MIT.


2 - Roboto - https://www.google.com/fonts/specimen/Roboto   
	License: Distributed under the terms of the Apache License, version 2.0 	http://www.apache.org/licenses/

3 - PT Self Design
	
	
4 - Other Images
	 

5 - Social Icons
	Icons have used from Font Awesome Icons http://fortawesome.github.io/Font-Awesome/icons/
	

Licensed under GPL. Fonts licensed under SIL OFL 1.1 http://scripts.sil.org/OFL

For any help you can mail us at support[at]pinnaclethemes.net