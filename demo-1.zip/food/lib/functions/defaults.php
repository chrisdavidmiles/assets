<?php
function complete_option_defaults() {
	$defaults = array(
		'converted' => '',
		'site_layout_id' => 'site_full',
		'single_post_layout_id' => 'single_layout1',
		'header_layout_id' => 'header_layout3',
		'center_width' => 83.50,
		'content_bg_color' => '#ffffff',
		'divider_icon' => 'fa-stop',
		'head_transparent' => '1',
		'trans_header_color' => '#fff',
		'totop_id' => '1',
		'footer_text_id' => __('Copyright 2017 Food | All Rights Reserved | Powered by <a href="https://www.pinnaclethemes.net/" target="_blank" rel="nofollow">Pinnacle Themes</a>', 'complete'),
		'phntp_text_id' => __('<i class="fa fa-clock-o"></i> Mon - Sat : 7:00AM to 9:00PM', 'complete'),
		'emltp_text' => __('<i class="fa fa-map-marker"></i>E102 Lorem Ben Street, London, United Kingdom', 'complete'),
		'sintp_text' => __('', 'complete'),
		'suptp_text' => __('<i class="fa fa-phone"></i>(+001) 321-456-789', 'complete'),
		'footmenu_id' => '1',
		'copyright_center' => '',
		
		'custom_slider' => '',
		
		'slider_type_id' => 'static',
		
		'slideefect' => 'fade',
		'slideanim' => '500',
		'slidepause' => '4000',
		'slidenav' => 'true',
		'slidepage' => 'true',
		
		'n_slide_time_id' => '6000',
		'slide_height' => '500px',
		'slidefont_size_id' => '36px',
		'slider_txt_hide' => '',

		'post_info_id' => '1',
		'post_nextprev_id' => '1',
		'post_comments_id' => '1',
		'page_header_color' => '#545556',
		'pageheader_bg_image' => '',
		'hide_pageheader' => '',
		'page_header_txtcolor' => '#555555',
		
		'post_header_color' => '#545556',
		'postheader_bg_image' => '',
		'hide_postheader' => '',		

		'blog_cat_id' => '',
		'blog_num_id' => '9',
		'blog_layout_id' => '',
		'show_blog_thumb' => '1',
		
		'sec_color_id' => '#ff9c00',
		'mnbg_color_id' => '#ff9c00',
		'submnu_textcolor_id' => '#000000',
		'submnbg_color_id' => '#ffffff',
		'mnshvr_color_id' => '#ff9c00',
		'mobbg_color_id' => '#383939',
		'mobbgtop_color_id' => '#ff9c00',
		'mobmenutxt_color_id' => '#FFFFFF',
		
		'mobtoggle_color_id' => '#000000',
		'mobtoggleinner_color_id' => '#FFFFFF',
		
		'sectxt_color_id' => '#FFFFFF',
		'content_font_id' =>  array('font-family' => 'Merriweather', 'font-size' => '14px'),
		'primtxt_color_id' => '#2b2b2b',
		'logo_image_id' => array(  'url'=>''),
		'logo_font_id' => array('font-family' => 'Lobster', 'font-size' => '48px'),
		'logo_color_id' => '#ffffff',
		'logolast_color_id' => '#ff9c00',
		
		'logo_image_height' => '46px;',
		'logo_image_width' => '106px;',
		'logo_margin_top' => '14px;',
		
		'tpbt_font_id' => array('font-family' => 'Roboto', 'font-size' => '13px'),
		'tpbt_color_id' => '#6a6a6a',
		'tpbt_hvcolor_id' => '#ff9c00',	
		
		'sldtitle_font_id' => array('font-family' => 'Great Vibes', 'font-size' => '71px'),
		'slddesc_font_id' => array('font-family' => 'PT Sans', 'font-size' => '12px'),
		'sldbtn_font_id' => array('font-family' => 'Roboto', 'font-size' => '13px'),
		
		'slidetitle_color_id' => '#ffffff',	
		'slddesc_color_id' => '#ffffff',	
		'sldbtntext_color_id' => '#ffffff',
		'sldbtn_color_id' => '#ff9c00',
		'sldbtn_hvcolor_id' => '#ff8800',	
		
		'slide_pager_color_id' => '#ffffff',	
		'slide_active_pager_color_id' => '#000000',	
		
			
		'global_link_color_id' => '#ff9c00',
		'global_link_hvcolor_id' => '#ff8800',		
		
		'global_h1_color_id' => '#282828',
		'global_h1_hvcolor_id' => '#ff9c00',	
		'global_h2_color_id' => '#282828',
		'global_h2_hvcolor_id' => '#ff9c00',
		'global_h3_color_id' => '#282828',
		'global_h3_hvcolor_id' => '#ff9c00',
		'global_h4_color_id' => '#282828',
		'global_h4_hvcolor_id' => '#ff9c00',
		'global_h5_color_id' => '#282828',
		'global_h5_hvcolor_id' => '#ff9c00',
		'global_h6_color_id' => '#282828',
		'global_h6_hvcolor_id' => '#ff9c00',	
		
		'post_meta_color_id' => '#888888',
		'post_datebox_bgcolor' => '#ffffff',
		'post_date_bgcolor' => '#ff9c00',
		
		'ourmenu_title_color' => '#ffffff',
		'ourmenu_desc_color' => '#8b8a8a',
		'ourmenu_button_color' => '#ffffff',
		'ourmenu_hover_color' => '#ff9c00',
		
		'team_box_color_id' => '#ececec',
		'team_boxhv_color_id' => '#ff9c00',
		
		
		
		'social_text_color_id' => '#ffffff',
		'social_icon_color_id' => '#131313',
		'social_hover_icon_color_id' => '#ff9c00',
		'testimonialbox_color_id' => '#ffffff',		
		'testimonialbox_txt_color' => '#ffffff',
		'testimonial_pager_color_id' => '#ffffff',
		 
		'testimonial_activepager_color_id' => '#000000',
		'gallery_filter_color_id' => '#ff9c00',
		'gallery_filtertxt_color_id' => '#000000',
		'gallery_activefiltertxt_color_id' => '#ffffff',
		'skillsbar_bgcolor_id' => '#f8f8f8',
		'skillsbar_text_color_id' => '#ffffff',								
		'global_h1_font_id' => array('font-family' => 'Lobster', 'font-size' => '40px'),
		'global_h2_font_id' => array('font-family' => 'Lobster', 'font-size' => '36px'),
		'global_h3_font_id' => array('font-family' => 'Roboto', 'font-size' => '18px'),
		'global_h4_font_id' => array('font-family' => 'Roboto', 'font-size' => '16px'),
		'global_h5_font_id' => array('font-family' => 'Roboto', 'font-size' => '15px'),
		'global_h6_font_id' => array('font-family' => 'Roboto', 'font-size' => '14px'),
		
		'contact_title' => 'Contact Info',
		'contact_address' => 'Donec ultricies mattis nulla Australia',
		'contact_phone' => '0789 256 321',
		'contact_email' => 'info@companyname.com',
		'contact_company_url' => 'http://demo.com',
		
		'head_bg_trans' => '0',
		'head_color_id' => '#1a1a1a',
		'head_info_color_id' => '#000000',
		'header_border_color' => '#dddddd',
		
		'head_menu_bgcolor' => '#000000',
		'menu_bg_trans' => '0.2',
		
		'menutxt_color_id' => '#ffffff',
		'menutxt_color_hover' => '#ffffff',
		'menutxt_color_active' => '#ffffff',
		'menu_size_id' => '15px',
		'sidebar_color_id' => '#FFFFFF',
		'sidebarborder_color_id' => '#eeeff5',
		'sidebar_tt_color_id' => '#282828',
		'sidebartxt_color_id' => '#999999',
		'sidebarlink_color_id' => '#282828',
		'sidebarlink_hover_color_id' => '#ff9c00',
		'flipbg_front_color_id' => '#ffffff',
		'flipbg_back_color_id' => '#f7f7f7',
		'flipborder_front_color_id' => '#e0e0e0',
		'flipborder_back_color_id' => '#000000',
		'divider_color_id' => '#8c8b8b',
		'wgttitle_size_id' => '20px',
		'timebox_color_id' => '#ffffff',
		'timeboxborder_color_id' => '#dedede',
		'gridbox_color_id' => '#ffffff',
		'gridboxborder_color_id' => '#cccccc',
		
		'service_box_bg' => '#ffffff',
		'service_box_bg_hover' => '#ffffff',
		'box_color_text' => '#545454',
		'go_bg_color' => '#ffffff',
		'box_color_border' => '#ff9c00',
		
		'expand_bg_color' => '#ff9c00',
		'expand_text_color' => '#000000',
		
		'h_seprator_color' => '#ff9c00',
		'h_seprator_text_color' => '#000000',
		
		'square_bg_color' => '#ffffff',
		'square_bg_hover_color' => '#79ab9f',
		'square_title_color' => '#000000',
		
		'style3_bg_color' => '#ffffff',
		'style3_hover_bg_color' => '#9f9f9f',
		'style3_border_color' => '#eaeaea',
		
		'perfect_bg_color' => '#ffffff',
		'perfect_border_color' => '#eaeaea',
		'perfect_hover_border_color' => '#ff9c00',
 
		'foot_layout_id' => '4',
		'footer_color_id' => '#000000',
		'footwdgtxt_color_id' => '#919090',
		'footer_title_color' => '#ffffff',
		'footer_linkhover_color' => '#ff9c00',
		'mnutitle_font_id' =>  array('font-family' => 'Roboto', 'subsets'=>'latin'),
		'title_txt_color_id' => '#282828',
		'link_color_id' => '#3590ea',
		'link_color_hover' => '#1e73be',
		'txt_upcase_id' => '',
		'mnutxt_upcase_id' => '',
		'copyright_bg_color' => '#0b0b0b',
		'copyright_txt_color' => '#858484',
		
		//Footer Info Box
		'footer_info_bgcolor' => '#161616',
		'footer_info_iconcolor' => '#ffffff',
		'footer_info_titlecolor' => '#ffffff',
		'footer_info_desccolor' => '#757575',
		'footer_info_shrtcolor' => '#ff9c00',
		'footer_info_dividercolor' => '#1f1f1f',		
		
		//Featured Box
		'featured_section_title' => __('Featured Boxes', 'complete'),
		'homeblock_bg_setting' => '',
		'ftd_bg_video' => '',
		'homeblock_title_color' => '#000000',
		'homeblock_color_id' => '#f2f2f2',
		'featured_image_height' => '70px;',
		'featured_image_width' => '70px;',
		'featured_excerpt' => '35',
		'featured_block_bg' => '#ffffff',
		'featured_block_button' => __('Read More', 'complete'),
		'recentpost_block_button' => __('Read More', 'complete'),
		
		'featured_block_button_bg' => '#383939',
		'featured_block_hover_button_bg' => '#ff9c00',
		
		'page-setting1_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon1.png'),
		'page-setting2_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon2.png'),
		'page-setting3_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon3.png'),
		'page-setting4_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon4.png'),
		
		'page-setting1' => '0',
		'page-setting2' => '0',
		'page-setting3' => '0',
		'page-setting4' => '0',
		'page-setting5' => '0',
		'page-setting6' => '0',
		'page-setting7' => '0',
		'page-setting8' => '0',
		'page-setting9' => '0',
		'page-setting10' => '0',
		'page-setting11' => '0',
		'page-setting12' => '0',
		'page-setting13' => '0',
		'page-setting14' => '0',
		'page-setting15' => '0',
		'page-setting16' => '0',
		'page-setting17' => '0',
		'hide_boxes' => '',
		
		//Home Section1
		'section1_bgcolor_id' => '#ffffff',
		'section1_bg_image' => ''.get_template_directory_uri().'/images/section-1-bg.jpg',
		'section1_bg_video' => '',
		'hide_boxes_section1' => '',
		//Home Section1
		
		//Home Section2
		'section2_bgcolor_id' => '',
		'section2_bg_image' => ''.get_template_directory_uri().'/images/section-2-bg.jpg',
		'section2_bg_video' => '',
		'hide_boxes_section2' => '',
		//Home Section2	
		
		//Home Section3
		'section3_bgcolor_id' => '#ffffff',
		'section3_bg_image' => '',
		'section3_bg_video' => '',
		'hide_boxes_section3' => '',
		//Home Section3	
		
		//Home Section4
		'section4_bgcolor_id' => '',
		'section4_bg_image' => ''.get_template_directory_uri().'/images/section-4-bg.jpg',
		'section4_bg_video' => '',
		'hide_boxes_section4' => '',
		//Home Section4		
		
		//Home Section5
		'section5_bgcolor_id' => '#ffffff',
		'section5_bg_image' => '',
		'section5_bg_video' => '',
		'hide_boxes_section5' => '',
		//Home Section5		
		
		//Home Section6
		'section6_bgcolor_id' => '#f6f6f6',
		'section6_bg_image' => ''.get_template_directory_uri().'/images/section-6-bg.jpg',
		'section5_bg_video' => '',
		'hide_boxes_section6' => '',
		//Home Section6	
		
		//Home Section7
		'section7_bgcolor_id' => '',
		'section7_bg_image' => ''.get_template_directory_uri().'/images/section-7-bg.jpg',
		'section7_bg_video' => '',
		'hide_boxes_section7' => '1',
		//Home Section7		
		
		//Home Section8
		'section8_bgcolor_id' => '#ff8800',
		'section8_bg_image' => '',
		'section8_bg_video' => '',
		'hide_boxes_section8' => '1',
		//Home Section8		
		
		//Home Section9
		'section9_bgcolor_id' => '#f6f6f6',
		'section9_bg_image' => '',
		'section9_bg_video' => '',
		'hide_boxes_section9' => '1',
		//Home Section9	
		
		//Home Section10
		'section10_bgcolor_id' => '',
		'section10_bg_image' => ''.get_template_directory_uri().'/images/section-10-bg.jpg',
		'section10_bg_video' => '',
		'hide_boxes_section10' => '1',
		//Home Section10
		
		//Home Section11
		'section11_bgcolor_id' => '#f6f6f6',
		'section11_bg_image' => '',
		'section11_bg_video' => '',
		'hide_boxes_section11' => '1',
		//Home Section11	
		
		//Home Section12
		'section12_bgcolor_id' => '',
		'section12_bg_image' => ''.get_template_directory_uri().'/images/section-12-bg.jpg',
		'section12_bg_video' => '',
		'hide_boxes_section12' => '1',
		//Home Section12
		
		//Home Section13
		'section13_bgcolor_id' => '#ffffff',
		'section13_bg_image' => '',
		'section13_bg_video' => '',
		'hide_boxes_section13' => '1',
		//Home Section13
		
		//Home Section14
		'section14_bgcolor_id' => '',
		'section14_bg_image' => ''.get_template_directory_uri().'/images/section-14-bg.jpg',
		'section14_bg_video' => '',
		'hide_boxes_section14' => '1',
		//Home Section14
		
		//Home Section15
		'section15_bgcolor_id' => '#f6f6f6',
		'section15_bg_image' => ''.get_template_directory_uri().'/images/section-6-bg.jpg',
		'section15_bg_video' => '',
		'hide_boxes_section15' => '1',
		//Home Section15
		
		//Home Section16
		'section16_bgcolor_id' => '#ffffff',
		'section16_bg_image' => '',
		'section16_bg_video' => '',
		'hide_boxes_section16' => '1',
		//Home Section16
		
		//Home Section17
		'section17_bgcolor_id' => '#ffffff',
		'section17_bg_image' => '',
		'section17_bg_video' => '',
		'hide_boxes_section17' => '1',
		//Home Section17												
		
		
		//Footer Column 1
		'foot_cols1_title' => __('ABOUT <span style="color:#ff9c00;">FOOD</span>', 'complete'),
		'foot_cols1_content' => '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
		
		<p>It has survived not only five centuries, but also the leap into electronic typesetting</p>',
		//Footer Column 1	
		
		//Footer Column 2
		'foot_cols2_title' => __('RECENT NEWS', 'complete'),
		'foot_cols2_content' => '[footerposts show="6" postexcerptlength=""]',
		//Footer Column 2	
		
		//Footer Column 3
		'foot_cols3_title' => __('QUICK LINKS', 'complete'),
		'foot_cols3_content' => '[footermenu]',
		//Footer Column 3
		
		//Footer Column 4
		'foot_cols4_title' => __('CONNECT WITH US', 'complete'),
		'foot_cols4_content' => '<p>Street 238,52 tempor <br />Donec ultricies mattis nulla, suscipit <br />risus tristique ut.</p>
		<p> Phone: 1.800.555.6789</p>
		<p> Email: <a href="mailto:support@sitename.com">support@sitename.com</a></p> 
		<p>Web: <a href="https://www.pinnaclethemes.net">Pinnacle Themes</a></p>
		
		[social_area]
		[social icon="facebook" link="#"]
		[social icon="twitter" link="#"]
		[social icon="google-plus" link="#"]
		[social icon="linkedin" link="#"]
		[social icon="pinterest" link="#"]
		[social icon="skype" link="#"]
		[/social_area]',
		//Footer Column 4																
		'social_button_style' => 'simple',
		'social_show_color' => '',
		'social_bookmark_pos' => 'footer',
		'social_bookmark_size' => 'normal',
		'social_single_id' => '1',
		'social_page_id' => '',
		
		//Footer Info Box 1
		'foot_infobox1_heading' => __('VISIT US', 'complete'),
		'foot_infobox1_icon' => '<i class="fa fa-map-o" aria-hidden="true"></i>',
		'foot_infobox1_description' => 'Aliquam porta tincidunt enim.',
		
		//Footer Info Box 2
		'foot_infobox2_heading' => __('EMAIL US', 'complete'),
		'foot_infobox2_icon' => '<i class="fa fa-envelope-o" aria-hidden="true"></i>',
		'foot_infobox2_description' => 'info@sitename.com',
		
		//Footer Info Box 3
		'foot_infobox3_heading' => __('CALL US', 'complete'),
		'foot_infobox3_icon' => '<i class="fa fa-phone" aria-hidden="true"></i>',
		'foot_infobox3_description' => '987 685 4528',
		
		'hide_foot_infobox' => '1',
		
		'post_lightbox_id' => '1',
		'post_gallery_id' => '1',
		'cat_layout_id' => '4',
		'hide_mob_slide' => '',
		'hide_mob_rightsdbr' => '',
		'hide_mob_page_header' => '1',
		'custom-css' => '',
	);
	
      $options = get_option('complete',$defaults);

      //Parse defaults again - see comments
      $options = wp_parse_args( $options, $defaults );

	return $options;
}?>